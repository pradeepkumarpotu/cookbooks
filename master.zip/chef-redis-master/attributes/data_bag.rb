default.redis.data_bag_name = "redis"
default.redis.instances = []
default.redis.sentinels = []
